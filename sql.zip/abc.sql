CREATE TABLE abc(
            no number(2),
            color varchar2(5 char),
            itime DATE DEFAULT sysdate
                    CONSTRAINT ABC_TIME_NN NOT NULL,
            isshow char(1) default 'Y'
                CONSTRAINT ABC_SHOW_CK CHECK (isshow IN('Y','N'))
                CONSTRAINT ABC_SHOW_NN NOT NULL
);

INSERT INTO
    abc(no,color)
VALUES(
    10, 'RED'
);
INSERT INTO
    abc(no,color)
VALUES(
    11, 'GREEN'
);
INSERT INTO
    abc
VALUES(
    12, 'BLUE',sysdate,'Y'
);